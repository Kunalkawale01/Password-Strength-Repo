sample_passwords = [
    'kunal123',
    'Kunal@123',
    'Kunal@2025!',
    'Dh@rm@_Flame99',
    '!T@thv@ya#2025_Fl@meWithin',
]


if __name__ == '__main__':
    import csv
    from pathlib import Path

    out = Path('data/sample_passwords.csv')
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['password', 'description'])
        for p in sample_passwords:
            writer.writerow([p, 'sample'])

    print(f' Wrote {out.resolve()}')
